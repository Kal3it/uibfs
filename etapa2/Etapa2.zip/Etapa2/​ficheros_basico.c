#include "Bloques.h"
#include "​ficheros_basico.h"
struct superbloque sb;
int tamMB(unsigned int ​ nbloques){
	int tam=(nbloques/8)/BLOCKSIZE;
	if( (nbloques/8)%BLOCKSIZE!=0){
		tam++;
	}
	return tam;
}
int tamAI(unsigned int ninodos){
	int tam=[(ninodos*TAM_INODO)/BLOCKSIZE];
	if([(ninodos*TAM_INODO)%BLOCKSIZE]!=0){
		tam++;
	}
	return tam;
}
int initSB(unsigned int nbloques, unsigned int ninodos){
	
	sb=malloc(sizeof(struct superbloque));
	sb.posPrimerBloqueMB=posSB+tamSB; //Posición del primer bloque del mapa de bits
  	sb.posUltimoBloqueMB=sb.posPrimerBloqueMB+tamMB(nbloques)-1; //Posición del último bloque del mapa de bits
  	sb.posPrimerBloqueAI=sb.posUltimoBloqueMB+1; //Posición del primer bloque del array de inodos
  	sb.posUltimoBloqueAI=sb.posPrimerBloqueAI+tamAI(ninodos)-1; //Posición del último bloque del array de inodos
  	sb.posPrimerBloqueDatos=sb.posUltimoBloqueAI+1; //Posición del primer bloque de datos
  	sb.posUltimoBloqueDatos=nbloques-1; //Posición del último bloque de datos
  	sb.posInodoRaiz=0; //Posición del inodo del directorio raíz
  	sb.posPrimerInodoLibre=1; //Posición del primer inodo libre
  	sb.cantBloquesLibres=nbloques; //Cantidad de bloques libres
  	sb.cantInodosLibres=ninodos-1 ; //Cantidad de inodos libres
  	sb.totBloques=nbloques; //Cantidad total de bloques
  	sb.totInodos=ninodos; //Cantidad total de inodos
  	bwrite(posSB,&sb);
}
int initMB(){
	unsigned char buffmb[BLOCKSIZE];
	memset(buffmb,0,BLOCKSIZE);
	//control de errores
	
	for(int i=sb.posPrimerBloqueMB;i<=sb.posUltimoBloqueMB;i++){
		bwrite(i,buffmb);
	}
	
	

}
int initAI(){
	struct inodo AI=malloc(sizeof(struct inodo));
	int UINT_MAX=99999:
	int contInodos = sb.posPrimerInodoLibre+1;
	//si hemos inicializado SB.posPrimerInodoLibre= 0
	for(int i=sb.posPrimerBloqueAI; i<=sb.posUltimoBloqueAI;i++){
		for (int j=0; j<BLOCKSIZE/TAM_INODO; j++){
	      	inodos[j].tipo := ‘l’;  //libre
	      	if(contInodos < ninodos){
				inodos[j].punterosDirectos[0] := contInodos;
				contInodos++;
			}else{
				inodos[j].punterosDirectos[0] := UINT_MAX;
				//salir del bucle 
			}
		}
	}


}